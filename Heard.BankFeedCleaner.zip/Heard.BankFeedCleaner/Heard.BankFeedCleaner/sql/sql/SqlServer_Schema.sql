-- SQL Server Schema
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'FileProcessingSummary')
BEGIN
    CREATE TABLE FileProcessingSummary (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        FileName NVARCHAR(255) NOT NULL,
        TotalRows INT NOT NULL,
        ValidRows INT NOT NULL,
        RejectedRows INT NOT NULL,
        Status VARCHAR(50) NOT NULL,
        ProcessedAt DATETIME DEFAULT GETUTCDATE()
    );
END

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'RejectedRowLogs')
BEGIN
    CREATE TABLE RejectedRowLogs (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        FileName NVARCHAR(255) NOT NULL,
        LineNumber INT NOT NULL,
        RawLine NVARCHAR(MAX) NOT NULL,
        Reasons NVARCHAR(MAX) NOT NULL,
        CreatedAt DATETIME DEFAULT GETUTCDATE()
    );
END


select * from RejectedRowLogs