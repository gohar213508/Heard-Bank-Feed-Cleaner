﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Heard.BankFeedCleaner.Models;

namespace Heard.BankFeedCleaner.Services
{
    public interface IProcessingLogStore
    {
        Task LogSummaryAsync(string fileName, int totalRows, int validRows, int rejectedRows, string status);
        Task LogValidTransactionsAsync(string fileName, List<CleanedTransaction> transactions);
        Task LogRejectedRowsAsync(string fileName, List<RejectedRow> rejectedRows);
    }
}