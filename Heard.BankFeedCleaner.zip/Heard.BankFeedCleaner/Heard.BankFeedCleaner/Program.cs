﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Heard.BankFeedCleaner.Services;

namespace Heard.BankFeedCleaner
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            // 1. Configuration Setup
            var config = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();

            // 2. Service Collection Setup (Dependency Injection)
            var services = new ServiceCollection();

            // Configuration ko DI Container mein register karein
            services.AddSingleton<IConfiguration>(config);

            // Dynamic Provider Wiring (SqlServer vs Oracle)
            string provider = config["LogProvider"] ?? "SqlServer";

            if (provider.Equals("Oracle", StringComparison.OrdinalIgnoreCase))
            {
                services.AddSingleton<OracleLogStore>();
                services.AddSingleton<IProcessingLogStore>(sp =>
                    new ResilientLogStore(sp.GetRequiredService<OracleLogStore>()));
            }
            else
            {
                services.AddSingleton<SqlServerLogStore>();
                services.AddSingleton<IProcessingLogStore>(sp =>
                    new ResilientLogStore(sp.GetRequiredService<SqlServerLogStore>()));
            }

            // Register BankFeedProcessor
            services.AddSingleton<BankFeedProcessor>();

            // Build Service Provider
            var serviceProvider = services.BuildServiceProvider();

            // 3. Absolute Path Resolution
            string projectDirectory = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\.."));

            string inputFolder = Path.Combine(projectDirectory, config["FileProcessing:InputFolder"] ?? "Input");
            string outputFolder = Path.Combine(projectDirectory, config["FileProcessing:OutputFolder"] ?? "Output");
            string archiveFolder = Path.Combine(projectDirectory, config["FileProcessing:ArchiveFolder"] ?? "Archive");
            string errorFolder = Path.Combine(projectDirectory, config["FileProcessing:ErrorFolder"] ?? "Error");

            Directory.CreateDirectory(inputFolder);
            Directory.CreateDirectory(outputFolder);
            Directory.CreateDirectory(archiveFolder);
            Directory.CreateDirectory(errorFolder);

            // 4. Resolve BankFeedProcessor from DI
            var processor = serviceProvider.GetRequiredService<BankFeedProcessor>();

            Console.WriteLine("--- Starting Bank Feed Processor ---");
            Console.WriteLine($"[LOG PROVIDER]: Configured as '{provider}'");
            Console.WriteLine($"[PATH DEBUG] Searching folder: {inputFolder}");

            var files = Directory.GetFiles(inputFolder, "*.csv");
            Console.WriteLine($"[PATH DEBUG] Total CSV Files Found: {files.Length}");

            foreach (var file in files)
            {
                await processor.ProcessFileAsync(file, outputFolder, archiveFolder, errorFolder);
            }

            Console.WriteLine("--- Processing Completed ---");
        }
    }
}