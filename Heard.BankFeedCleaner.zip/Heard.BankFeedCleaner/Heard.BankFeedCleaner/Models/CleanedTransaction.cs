﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Heard.BankFeedCleaner.Models
{
    public class CleanedTransaction
    {
        public string TxnId { get; set; } = string.Empty;
        public string TxnDate { get; set; } = string.Empty; // yyyy-MM-dd
        public string AccountNo { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Currency { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty; // CR or DR
        public string Narration { get; set; } = string.Empty;
    }
}
