﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Heard.BankFeedCleaner.Models
{
    public class RejectedRow
    {
        public int LineNumber { get; set; }
        public string RawLine { get; set; } = string.Empty;
        public string Reasons { get; set; } = string.Empty;
    }
}
