﻿using Heard.BankFeedCleaner.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Heard.BankFeedCleaner.Services
{
    public class BankFeedProcessor
    {
        private static readonly Regex TxnIdRegex = new(@"^TXN-\d{8}$", RegexOptions.Compiled);
        private static readonly Regex IbanRegex = new(@"^PK\d{2}[A-Z]{4}\d{16}$", RegexOptions.Compiled);

        private readonly IProcessingLogStore _logStore;

        public BankFeedProcessor(IProcessingLogStore logStore)
        {
            _logStore = logStore;
        }

        public async Task ProcessFileAsync(string filePath, string outputDir, string archiveDir, string errorDir)
        {
            var fileName = Path.GetFileName(filePath);
            var lines = File.ReadAllLines(filePath);

            if (lines.Length == 0)
            {
                MoveToErrorFolder(filePath, errorDir, "File is completely empty.");
                await TryLogSummarySafely(fileName, 0, 0, 0, "FAILED_EMPTY");
                return;
            }

            // 1. Header Validation
            var headerFields = ParseCsvLine(lines[0]);
            string[] expectedHeaders = { "TxnId", "TxnDate", "AccountNo", "Amount", "Currency", "Type", "Narration" };

            if (headerFields.Length < expectedHeaders.Length)
            {
                MoveToErrorFolder(filePath, errorDir, "Header column count is insufficient.");
                await TryLogSummarySafely(fileName, lines.Length, 0, lines.Length, "FAILED_HEADER");
                return;
            }

            for (int i = 0; i < expectedHeaders.Length; i++)
            {
                if (!headerFields[i].Trim().Equals(expectedHeaders[i], StringComparison.OrdinalIgnoreCase))
                {
                    MoveToErrorFolder(filePath, errorDir, $"Header mismatch at column {i + 1}. Expected: {expectedHeaders[i]}, Got: {headerFields[i]}");
                    await TryLogSummarySafely(fileName, lines.Length, 0, lines.Length, "FAILED_HEADER");
                    return;
                }
            }

            // 2. Data Rows Validation
            var validTransactions = new List<CleanedTransaction>();
            var rejectedRows = new List<RejectedRow>();
            var processedTxnIds = new HashSet<string>();

            for (int i = 1; i < lines.Length; i++)
            {
                var rawLine = lines[i];
                if (string.IsNullOrWhiteSpace(rawLine)) continue;

                var fields = ParseCsvLine(rawLine);
                var (txn, errors) = ValidateAndCleanRow(fields, processedTxnIds);

                if (txn != null)
                {
                    validTransactions.Add(txn);
                }
                else
                {
                    rejectedRows.Add(new RejectedRow
                    {
                        LineNumber = i + 1,
                        RawLine = rawLine,
                        Reasons = string.Join(" | ", errors)
                    });
                }
            }

            // 3. Generate Output JSON
            var baseName = Path.GetFileNameWithoutExtension(fileName);
            var jsonPath = Path.Combine(outputDir, $"{baseName}.json");
            var jsonOptions = new JsonSerializerOptions { WriteIndented = true };
            File.WriteAllText(jsonPath, JsonSerializer.Serialize(validTransactions, jsonOptions));

            // 4. Generate Error CSV (if any rejected rows)
            if (rejectedRows.Count > 0)
            {
                var errorCsvPath = Path.Combine(errorDir, $"{baseName}_errors.csv");
                var sb = new StringBuilder();
                sb.AppendLine("LineNumber,RawLine,Reasons");

                foreach (var row in rejectedRows)
                {
                    var escapedRaw = $"\"{row.RawLine.Replace("\"", "\"\"")}\"";
                    var escapedReasons = $"\"{row.Reasons.Replace("\"", "\"\"")}\"";
                    sb.AppendLine($"{row.LineNumber},{escapedRaw},{escapedReasons}");
                }

                File.WriteAllText(errorCsvPath, sb.ToString());
            }

            // 5. Database Operations (with Resilient Fallback)
            try
            {
                await _logStore.LogValidTransactionsAsync(fileName, validTransactions);
                await _logStore.LogRejectedRowsAsync(fileName, rejectedRows);
                await _logStore.LogSummaryAsync(fileName, lines.Length - 1, validTransactions.Count, rejectedRows.Count, "SUCCESS");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DB WARNING] Database persistence failed for '{fileName}'. Error: {ex.Message}. Continuing file archiving...");
            }

            // 6. Move Original File to Archive with Timestamp
            var timestamp = DateTime.Now.ToString("yyyyMMddTHHmmss");
            var archiveFileName = $"{baseName}_{timestamp}{Path.GetExtension(fileName)}";
            var archivePath = Path.Combine(archiveDir, archiveFileName);

            MoveFileSafely(filePath, archivePath);
            Console.WriteLine($"[SUCCESS] Processed: {fileName} | Valid: {validTransactions.Count} | Errors: {rejectedRows.Count}");
        }

        private async Task TryLogSummarySafely(string fileName, int total, int valid, int rejected, string status)
        {
            try
            {
                await _logStore.LogSummaryAsync(fileName, total, valid, rejected, status);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DB WARNING] Summary log failed for '{fileName}': {ex.Message}");
            }
        }

        private (CleanedTransaction? Transaction, List<string> Errors) ValidateAndCleanRow(string[] fields, HashSet<string> processedTxnIds)
        {
            var errors = new List<string>();

            if (fields.Length < 7)
            {
                errors.Add("Wrong number of columns.");
                return (null, errors);
            }

            var rawTxnId = fields[0].Trim().ToUpperInvariant();
            var rawDate = fields[1].Trim();
            var rawAccountNo = fields[2].Replace(" ", "").Replace("-", "").ToUpperInvariant();
            var rawAmount = fields[3].Trim();
            var rawCurrency = fields[4].Trim().ToUpperInvariant();
            var rawType = fields[5].Trim().ToUpperInvariant();
            var rawNarration = fields[6].Trim();

            // Rule 1: TxnId
            if (!TxnIdRegex.IsMatch(rawTxnId))
            {
                errors.Add("Invalid TxnId format (expected TXN- followed by 8 digits).");
            }
            else if (processedTxnIds.Contains(rawTxnId))
            {
                errors.Add($"Duplicate TxnId '{rawTxnId}' in same file.");
            }

            // Rule 2: TxnDate
            string[] formats = { "dd/MM/yyyy", "yyyy-MM-dd", "dd-MMM-yyyy" };
            if (!DateTime.TryParseExact(rawDate, formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsedDate))
            {
                errors.Add("Invalid date format (must be dd/MM/yyyy, yyyy-MM-dd, or dd-MMM-yyyy).");
            }
            else if (parsedDate.Date > DateTime.UtcNow.Date)
            {
                errors.Add("Transaction date cannot be in the future.");
            }

            // Rule 3: AccountNo (Pakistani IBAN)
            if (!IbanRegex.IsMatch(rawAccountNo))
            {
                errors.Add("Invalid Pakistani IBAN format.");
            }

            // Rule 4: Type
            string cleanType = "";
            if (rawType is "CR" or "CREDIT") cleanType = "CR";
            else if (rawType is "DR" or "DEBIT") cleanType = "DR";
            else errors.Add("Type must be CR, CREDIT, DR, or DEBIT.");

            // Rule 5: Currency
            string cleanCurrency = string.IsNullOrWhiteSpace(rawCurrency) ? "PKR" : rawCurrency;
            if (cleanCurrency is not ("PKR" or "USD"))
            {
                errors.Add("Currency must be PKR or USD.");
            }

            // Rule 6: Amount
            bool isNegative = rawAmount.StartsWith("(") && rawAmount.EndsWith(")") || rawAmount.StartsWith("-");
            string cleanedAmountStr = rawAmount.Replace("PKR", "", StringComparison.OrdinalIgnoreCase)
                                              .Replace("Rs.", "", StringComparison.OrdinalIgnoreCase)
                                              .Replace("Rs", "", StringComparison.OrdinalIgnoreCase)
                                              .Replace(",", "")
                                              .Replace("(", "")
                                              .Replace(")", "")
                                              .Trim();

            if (!decimal.TryParse(cleanedAmountStr, NumberStyles.Any, CultureInfo.InvariantCulture, out var amountVal) || amountVal <= 0)
            {
                errors.Add("Amount must be a positive non-zero number.");
            }
            else
            {
                if (decimal.Round(amountVal, 2) != amountVal)
                {
                    errors.Add("Amount must have at most 2 decimal places.");
                }

                if (isNegative && cleanType != "DR")
                {
                    errors.Add("Negative amounts are only allowed for DR (Debit) transactions.");
                }
            }

            // Rule 7: Narration
            string cleanNarration = Regex.Replace(rawNarration, @"\s+", " ").Trim();
            if (cleanNarration.Length > 100)
            {
                cleanNarration = cleanNarration.Substring(0, 100);
            }

            if (errors.Count > 0)
            {
                return (null, errors);
            }

            processedTxnIds.Add(rawTxnId);

            var cleanTxn = new CleanedTransaction
            {
                TxnId = rawTxnId,
                TxnDate = parsedDate.ToString("yyyy-MM-dd"),
                AccountNo = rawAccountNo,
                Amount = amountVal,
                Currency = cleanCurrency,
                Type = cleanType,
                Narration = cleanNarration
            };

            return (cleanTxn, errors);
        }

        private string[] ParseCsvLine(string line)
        {
            var fields = new List<string>();
            var currentField = new StringBuilder();
            bool inQuotes = false;

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"')
                {
                    if (inQuotes && i + 1 < line.Length && line[i + 1] == '"')
                    {
                        currentField.Append('"');
                        i++;
                    }
                    else
                    {
                        inQuotes = !inQuotes;
                    }
                }
                else if (c == ',' && !inQuotes)
                {
                    fields.Add(currentField.ToString());
                    currentField.Clear();
                }
                else
                {
                    currentField.Append(c);
                }
            }
            fields.Add(currentField.ToString());
            return fields.ToArray();
        }

        private void MoveToErrorFolder(string filePath, string errorDir, string reason)
        {
            var fileName = Path.GetFileName(filePath);
            var destPath = Path.Combine(errorDir, fileName);
            MoveFileSafely(filePath, destPath);

            var reasonLogPath = Path.Combine(errorDir, $"{Path.GetFileNameWithoutExtension(fileName)}_header_error.txt");
            File.WriteAllText(reasonLogPath, reason);
            Console.WriteLine($"[HEADER REJECTED] File: {fileName} moved to Error folder. Reason: {reason}");
        }

        private void MoveFileSafely(string sourcePath, string destPath)
        {
            if (File.Exists(destPath)) File.Delete(destPath);
            File.Move(sourcePath, destPath);
        }
    }
}