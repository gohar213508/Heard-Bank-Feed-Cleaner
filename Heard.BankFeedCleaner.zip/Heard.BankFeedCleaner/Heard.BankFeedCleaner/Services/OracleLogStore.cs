﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using Heard.BankFeedCleaner.Models;

namespace Heard.BankFeedCleaner.Services
{
    public class OracleLogStore : IProcessingLogStore
    {
        private readonly string _connectionString;

        public OracleLogStore(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("OracleConnection")
                ?? "Data Source=localhost:1521/XEPDB1;User Id=system;Password=oracle;";
        }

        public async Task LogSummaryAsync(string fileName, int totalRows, int validRows, int rejectedRows, string status)
        {
            using var conn = new OracleConnection(_connectionString);
            await conn.OpenAsync();

            string query = @"
                INSERT INTO FileProcessingSummary (FileName, TotalRows, ValidRows, RejectedRows, Status)
                VALUES (:FileName, :TotalRows, :ValidRows, :RejectedRows, :Status)";

            using var cmd = new OracleCommand(query, conn);
            cmd.Parameters.Add("FileName", OracleDbType.Varchar2, 255).Value = fileName;
            cmd.Parameters.Add("TotalRows", OracleDbType.Int32).Value = totalRows;
            cmd.Parameters.Add("ValidRows", OracleDbType.Int32).Value = validRows;
            cmd.Parameters.Add("RejectedRows", OracleDbType.Int32).Value = rejectedRows;
            cmd.Parameters.Add("Status", OracleDbType.Varchar2, 50).Value = status;

            await cmd.ExecuteNonQueryAsync();
        }

        public async Task LogValidTransactionsAsync(string fileName, List<CleanedTransaction> transactions)
        {
            if (transactions == null || transactions.Count == 0) return;

            using var conn = new OracleConnection(_connectionString);
            await conn.OpenAsync();

            using var transaction = conn.BeginTransaction();

            try
            {
                string query = @"
                    INSERT INTO CleanedTransactions 
                    (FileName, TxnId, TxnDate, AccountNo, Amount, Currency, Type, Narration)
                    VALUES 
                    (:FileName, :TxnId, :TxnDate, :AccountNo, :Amount, :Currency, :Type, :Narration)";

                foreach (var item in transactions)
                {
                    using var cmd = new OracleCommand(query, conn);
                    cmd.Transaction = transaction;
                    cmd.Parameters.Add("FileName", OracleDbType.Varchar2, 255).Value = fileName;
                    cmd.Parameters.Add("TxnId", OracleDbType.Varchar2, 20).Value = item.TxnId;
                    cmd.Parameters.Add("TxnDate", OracleDbType.Varchar2, 10).Value = item.TxnDate;
                    cmd.Parameters.Add("AccountNo", OracleDbType.Varchar2, 34).Value = item.AccountNo;
                    cmd.Parameters.Add("Amount", OracleDbType.Decimal).Value = item.Amount;
                    cmd.Parameters.Add("Currency", OracleDbType.Varchar2, 3).Value = item.Currency;
                    cmd.Parameters.Add("Type", OracleDbType.Varchar2, 2).Value = item.Type;
                    cmd.Parameters.Add("Narration", OracleDbType.Varchar2, 100).Value = (object)item.Narration ?? DBNull.Value;

                    await cmd.ExecuteNonQueryAsync();
                }

                await transaction.CommitAsync();
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task LogRejectedRowsAsync(string fileName, List<RejectedRow> rejectedRows)
        {
            if (rejectedRows == null || rejectedRows.Count == 0) return;

            using var conn = new OracleConnection(_connectionString);
            await conn.OpenAsync();

            using var transaction = conn.BeginTransaction();

            try
            {
                string query = @"
                    INSERT INTO RejectedRowLogs 
                    (FileName, LineNumber, RawLine, Reasons)
                    VALUES 
                    (:FileName, :LineNumber, :RawLine, :Reasons)";

                foreach (var row in rejectedRows)
                {
                    using var cmd = new OracleCommand(query, conn);
                    cmd.Transaction = transaction;
                    cmd.Parameters.Add("FileName", OracleDbType.Varchar2, 255).Value = fileName;
                    cmd.Parameters.Add("LineNumber", OracleDbType.Int32).Value = row.LineNumber;
                    cmd.Parameters.Add("RawLine", OracleDbType.Clob).Value = row.RawLine;
                    cmd.Parameters.Add("Reasons", OracleDbType.Clob).Value = row.Reasons;

                    await cmd.ExecuteNonQueryAsync();
                }

                await transaction.CommitAsync();
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }
    }
}