﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Heard.BankFeedCleaner.Models;

namespace Heard.BankFeedCleaner.Services
{
    public class SqlServerLogStore : IProcessingLogStore
    {
        private readonly string _connectionString;

        public SqlServerLogStore(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("SqlServerConnection")
                ?? configuration.GetConnectionString("DefaultConnection")
                ?? throw new InvalidOperationException("SQL Server Connection string is missing in appsettings.json");
        }

        public async Task LogSummaryAsync(string fileName, int totalRows, int validRows, int rejectedRows, string status)
        {
            using var conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            string query = @"
                INSERT INTO FileProcessingSummary (FileName, TotalRows, ValidRows, RejectedRows, Status, ProcessedAt)
                VALUES (@FileName, @TotalRows, @ValidRows, @RejectedRows, @Status, GETUTCDATE());";

            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.Add("@FileName", SqlDbType.NVarChar, 255).Value = fileName;
            cmd.Parameters.Add("@TotalRows", SqlDbType.Int).Value = totalRows;
            cmd.Parameters.Add("@ValidRows", SqlDbType.Int).Value = validRows;
            cmd.Parameters.Add("@RejectedRows", SqlDbType.Int).Value = rejectedRows;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50).Value = status;

            await cmd.ExecuteNonQueryAsync();
        }

        public async Task LogValidTransactionsAsync(string fileName, List<CleanedTransaction> transactions)
        {
            if (transactions == null || transactions.Count == 0) return;

            using var conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            using var transaction = conn.BeginTransaction();

            try
            {
                string query = @"
                    INSERT INTO CleanedTransactions 
                    (FileName, TxnId, TxnDate, AccountNo, Amount, Currency, Type, Narration, CreatedAt)
                    VALUES 
                    (@FileName, @TxnId, @TxnDate, @AccountNo, @Amount, @Currency, @Type, @Narration, GETUTCDATE());";

                foreach (var item in transactions)
                {
                    using var cmd = new SqlCommand(query, conn, transaction);
                    cmd.Parameters.Add("@FileName", SqlDbType.NVarChar, 255).Value = fileName;
                    cmd.Parameters.Add("@TxnId", SqlDbType.VarChar, 20).Value = item.TxnId;
                    cmd.Parameters.Add("@TxnDate", SqlDbType.VarChar, 10).Value = item.TxnDate;
                    cmd.Parameters.Add("@AccountNo", SqlDbType.VarChar, 34).Value = item.AccountNo;
                    cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = item.Amount;
                    cmd.Parameters.Add("@Currency", SqlDbType.VarChar, 3).Value = item.Currency;
                    cmd.Parameters.Add("@Type", SqlDbType.VarChar, 2).Value = item.Type;
                    cmd.Parameters.Add("@Narration", SqlDbType.NVarChar, 100).Value = (object)item.Narration ?? DBNull.Value;

                    await cmd.ExecuteNonQueryAsync();
                }

                await transaction.CommitAsync();
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        public async Task LogRejectedRowsAsync(string fileName, List<RejectedRow> rejectedRows)
        {
            if (rejectedRows == null || rejectedRows.Count == 0) return;

            using var conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            using var transaction = conn.BeginTransaction();

            try
            {
                string query = @"
                    INSERT INTO RejectedRowLogs 
                    (FileName, LineNumber, RawLine, Reasons, CreatedAt)
                    VALUES 
                    (@FileName, @LineNumber, @RawLine, @Reasons, GETUTCDATE());";

                foreach (var row in rejectedRows)
                {
                    using var cmd = new SqlCommand(query, conn, transaction);
                    cmd.Parameters.Add("@FileName", SqlDbType.NVarChar, 255).Value = fileName;
                    cmd.Parameters.Add("@LineNumber", SqlDbType.Int).Value = row.LineNumber;
                    cmd.Parameters.Add("@RawLine", SqlDbType.NVarChar, -1).Value = row.RawLine;
                    cmd.Parameters.Add("@Reasons", SqlDbType.NVarChar, -1).Value = row.Reasons;

                    await cmd.ExecuteNonQueryAsync();
                }

                await transaction.CommitAsync();
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }
    }
}