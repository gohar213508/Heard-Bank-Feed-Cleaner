﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Heard.BankFeedCleaner.Models;

namespace Heard.BankFeedCleaner.Services
{
    public class ResilientLogStore : IProcessingLogStore
    {
        private readonly IProcessingLogStore _innerStore;
        private readonly string _fallbackFolderPath = "./Data/FallbackLogs";

        public ResilientLogStore(IProcessingLogStore innerStore)
        {
            _innerStore = innerStore;
            if (!Directory.Exists(_fallbackFolderPath))
            {
                Directory.CreateDirectory(_fallbackFolderPath);
            }
        }

        public async Task LogSummaryAsync(string fileName, int totalRows, int validRows, int rejectedRows, string status)
        {
            try
            {
                await _innerStore.LogSummaryAsync(fileName, totalRows, validRows, rejectedRows, status);
            }
            catch (Exception ex)
            {
                var fallbackLog = new
                {
                    Type = "Summary",
                    FileName = fileName,
                    TotalRows = totalRows,
                    ValidRows = validRows,
                    RejectedRows = rejectedRows,
                    Status = status,
                    ErrorMessage = ex.Message,
                    LoggedAt = DateTime.UtcNow
                };

                string path = Path.Combine(_fallbackFolderPath, $"fallback_summary_{DateTime.Now:yyyyMMdd_HHmmss}.json");
                await File.WriteAllTextAsync(path, JsonSerializer.Serialize(fallbackLog));
            }
        }

        public async Task LogValidTransactionsAsync(string fileName, List<CleanedTransaction> transactions)
        {
            try
            {
                await _innerStore.LogValidTransactionsAsync(fileName, transactions);
            }
            catch (Exception ex)
            {
                var fallbackLog = new
                {
                    Type = "ValidTransactions",
                    FileName = fileName,
                    Count = transactions?.Count ?? 0,
                    Data = transactions,
                    ErrorMessage = ex.Message,
                    LoggedAt = DateTime.UtcNow
                };

                string path = Path.Combine(_fallbackFolderPath, $"fallback_valid_txns_{DateTime.Now:yyyyMMdd_HHmmss}.json");
                await File.WriteAllTextAsync(path, JsonSerializer.Serialize(fallbackLog));
            }
        }

        public async Task LogRejectedRowsAsync(string fileName, List<RejectedRow> rejectedRows)
        {
            try
            {
                await _innerStore.LogRejectedRowsAsync(fileName, rejectedRows);
            }
            catch (Exception ex)
            {
                var fallbackLog = new
                {
                    Type = "RejectedRows",
                    FileName = fileName,
                    Count = rejectedRows?.Count ?? 0,
                    Data = rejectedRows,
                    ErrorMessage = ex.Message,
                    LoggedAt = DateTime.UtcNow
                };

                string path = Path.Combine(_fallbackFolderPath, $"fallback_rejected_rows_{DateTime.Now:yyyyMMdd_HHmmss}.json");
                await File.WriteAllTextAsync(path, JsonSerializer.Serialize(fallbackLog));
            }
        }
    }
}